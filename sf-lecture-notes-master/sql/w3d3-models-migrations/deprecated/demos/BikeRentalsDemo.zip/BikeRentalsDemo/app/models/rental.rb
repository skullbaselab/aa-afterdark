class Rental < ActiveRecord::Base
  validates :bike_id, presence: true
  validates :renter_id, presence: true

  belongs_to :renters,
    primary_key: :id,
    foreign_key: :renter_id,
    class_name: "User"

  belongs_to :bikes,
    primary_key: :id,
    foreign_key: :bike_id,
    class_name: "Bike"
end
