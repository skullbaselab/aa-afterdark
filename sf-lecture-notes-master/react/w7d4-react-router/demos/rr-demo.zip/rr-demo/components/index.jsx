import React from 'react'
import { Route, NavLink, Switch, Redirect } from 'react-router-dom'

import Pikachu from './pikachu'
import Pokemon from './pokemon'
import Default from './default'

export default () => (
  <div>
    <h1>Cool Routing App</h1>
    <NavLink to="/">Home</NavLink>
    <NavLink to="/pokemon">Pokemon</NavLink>
    <NavLink to="/pokemon/pikachu">Pikachu</NavLink>
    <NavLink to="/pokemon/bulbasaur">Bulbasaur</NavLink>

    <Switch>
      <Route path="/pokemon/pikachu" component={Pikachu} />
      <Route path="/pokemon/bulbasaur" render={() => {
        return <Redirect to="/pokemon/pikachu" />
      }} />
      <Route path="/pokemon" component={Pokemon} />
      <Route render={({match, location}) => <Default match={match} 
                                                     location={location} 
                                                     extra="more props!"
                                                     />} />
    </Switch>
  </div>
)