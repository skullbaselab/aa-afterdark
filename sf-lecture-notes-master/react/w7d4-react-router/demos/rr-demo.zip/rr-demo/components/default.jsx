import React from 'react'

export default (props) => (
  <div>
    <img src="https://media.giphy.com/media/ZgqJGwh2tLj5C/giphy.gif" />
    <p>
      { !props.match.isExact ? `"${props.location.pathname}" tried to
      match the other route paths but ended up at:
      "${props.match.url}"` : `` }
    </p>
    <p>
      {props.extra}
    </p>
  </div>
)