import { RECEIVE_SEARCH_GIPHYS } from '../actions/giphy_actions';
