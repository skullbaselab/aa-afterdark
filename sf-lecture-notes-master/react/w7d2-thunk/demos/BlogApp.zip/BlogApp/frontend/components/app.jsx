import React from 'react';
import PostContainer from './posts/post_container';

const App = () => (
  <div className="app">
    <h1>Blog</h1>
    <PostContainer />
  </div>
);

export default App;
