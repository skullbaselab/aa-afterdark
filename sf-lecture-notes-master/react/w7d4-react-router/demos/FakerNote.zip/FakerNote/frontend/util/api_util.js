export const fetchUsers = () => (
  $.ajax({
    method: 'GET',
    url: 'api/users'
  })
);

export const fetchNotebooks = userId => (
  $.ajax({
    method: 'GET',
    url: `api/users/${userId}/notebooks`
  })
);
