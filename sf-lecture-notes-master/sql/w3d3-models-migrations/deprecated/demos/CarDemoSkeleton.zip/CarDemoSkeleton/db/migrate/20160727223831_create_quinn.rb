class CreateQuinn < ActiveRecord::Migration
  def change
    create_table :quinns do |t|
    end
  end
end
