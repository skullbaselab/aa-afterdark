import { PostConstants } from '../actions/post_actions';
import merge from 'lodash/merge';

const PostsReducer = function(state = [], action){
  switch(action.type){
    case PostConstants.POSTS_RECEIVED:
      return action.posts;
    default:
      return state;
  }
};

export default PostsReducer;
