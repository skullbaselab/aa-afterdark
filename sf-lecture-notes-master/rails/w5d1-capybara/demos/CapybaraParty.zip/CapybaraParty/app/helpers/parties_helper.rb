module PartiesHelper
end
