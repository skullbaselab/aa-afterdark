Rails.application.routes.draw do
  resources :plants, only: [:index, :show, :new, :create, :edit, :update]
end
