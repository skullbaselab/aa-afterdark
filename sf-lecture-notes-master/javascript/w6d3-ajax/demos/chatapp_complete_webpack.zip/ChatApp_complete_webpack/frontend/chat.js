var ChatMachine = require("./chatMachine.js");

window.ChatMachine = ChatMachine;
