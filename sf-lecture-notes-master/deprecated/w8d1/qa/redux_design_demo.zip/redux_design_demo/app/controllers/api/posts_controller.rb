class Api::PostsController < ApplicationController
  def index
    @posts = Post.all
    if params[:search] && !params[:search].empty?
      @posts = @posts.where(
        [
          'title LIKE :query OR body LIKE :query',
          {query: "%#{params[:search]}%"}
        ]
      )
    end
  end

  def show
    @posts = Post.find(params[:id])
  end

  private

  def search_params
    params.permit(:title, :body)
  end
end
