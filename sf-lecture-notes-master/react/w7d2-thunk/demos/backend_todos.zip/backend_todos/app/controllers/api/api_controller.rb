class Api::ApiController < ApplicationController
end
