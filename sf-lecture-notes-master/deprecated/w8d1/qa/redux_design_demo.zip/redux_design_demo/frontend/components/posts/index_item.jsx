import React from 'react';

const PostsIndexItem = ({post}) => {
  return (
    <li className="posts-index-item">
      <h4>{post.title}</h4>
      <p>{post.body}</p>
    </li>
  );
};

export default PostsIndexItem;