import React from 'react';
import ReactDOM from 'react-dom';
import configureStore from './store/store';
import Root from './components/root';
import { requestPosts } from './actions/post_actions';

document.addEventListener('DOMContentLoaded', () => {
  const store = configureStore();
  const main = document.getElementById('main');
  ReactDOM.render(<Root store={store}/>, main);
  store.dispatch(requestPosts());
  window.store = store;
});
