FactoryGirl.define do
  factory :board_membership do
    
  end
end
