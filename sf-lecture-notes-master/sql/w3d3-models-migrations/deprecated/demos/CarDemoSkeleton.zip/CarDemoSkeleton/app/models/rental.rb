class Rental < ActiveRecord::Base

end
