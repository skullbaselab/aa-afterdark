import { combineReducers } from 'redux';

import PostsReducer from '../reducers/posts_reducer';
import SearchParamsReducer from '../reducers/search_params_reducer';

const RootReducer = combineReducers({
  posts: PostsReducer,
  searchParams: SearchParamsReducer
});

export default RootReducer;
