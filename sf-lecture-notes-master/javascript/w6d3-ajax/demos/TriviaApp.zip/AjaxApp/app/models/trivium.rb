class Trivium < ApplicationRecord
  validates :fact, presence: true
end
