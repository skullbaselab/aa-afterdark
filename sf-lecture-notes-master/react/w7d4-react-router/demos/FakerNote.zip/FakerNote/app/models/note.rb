class Note < ApplicationRecord
	belongs_to :notebook
end
