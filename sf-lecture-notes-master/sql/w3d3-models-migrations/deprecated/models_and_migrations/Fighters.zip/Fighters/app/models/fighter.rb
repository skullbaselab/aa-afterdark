# == Schema Information
#
# Table name: fighters
#
#  id         :integer          not null, primary key
#  name       :string           not null
#  created_at :datetime
#  updated_at :datetime
#  coach_id   :integer
#

class Fighter < ActiveRecord::Base
  validates :name, presence: true
  belongs_to :coach,
    foreign_key: :coach_id,
    primary_key: :id,
    class_name: 'Coach'

  has_one :gym,
    through: :coach,
    source: :gym


  # ANTIPATTERN DO NOT DO THIS
  # def coach
  #   Coach.find(coach_id)
  # end
end
