class CreatePlants < ActiveRecord::Migration
  def change
    create_table :plants do |t|
      t.string :plant_type
      t.string :name, null: false
      t.text :description
      t.timestamps null: false
    end
  end
end
