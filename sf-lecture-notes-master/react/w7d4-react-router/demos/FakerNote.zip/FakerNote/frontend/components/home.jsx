import React from 'react';

const Home = (props) => (
		<section>
			<h1>Fakernote</h1>
			{ props.children }
		</section>
);

export default Home;
