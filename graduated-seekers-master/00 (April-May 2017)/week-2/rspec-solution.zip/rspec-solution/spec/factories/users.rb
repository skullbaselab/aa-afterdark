FactoryGirl.define do
  factory :user do
    username 'guest'
    password 'password'
  end
end
