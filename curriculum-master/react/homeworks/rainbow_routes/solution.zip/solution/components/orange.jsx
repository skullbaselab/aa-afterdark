import React from 'react';

const Orange = () => (
  <div>
    <h3 className="orange"></h3>
  </div>
);

export default Orange;
