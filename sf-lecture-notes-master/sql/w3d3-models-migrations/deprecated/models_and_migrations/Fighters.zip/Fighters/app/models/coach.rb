# == Schema Information
#
# Table name: coaches
#
#  id     :integer          not null, primary key
#  name   :string           not null
#  gym_id :integer
#

class Coach < ActiveRecord::Base
  validates :name, presence: true
  has_many :fighters,
    foreign_key: :coach_id,
    primary_key: :id,
    class_name: 'Fighter'

  belongs_to :gym,
    foreign_key: :gym_id,
    primary_key: :id,
    class_name: 'Gym'

  # ANTIPATTERN DO NOT DO THIS
  # def fighters
  #   Fighter.where(coach_id: id)
  # end
end
