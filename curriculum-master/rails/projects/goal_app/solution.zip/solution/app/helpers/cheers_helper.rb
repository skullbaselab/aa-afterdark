module CheersHelper
end
