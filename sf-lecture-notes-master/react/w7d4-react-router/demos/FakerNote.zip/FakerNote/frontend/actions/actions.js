import { fetchUsers, fetchNotebooks } from '../util/api_util';

export const receiveUsers = (users) => ({
	type: 'RECEIVE_USERS',
	users
});

export const receiveNotebooks = (notebooks) => ({
	type: 'RECEIVE_NOTEBOOKS',
	notebooks
});

export const removeNotebooks = () => ({
	type: 'REMOVE_NOTEBOOKS'
});

export const requestUsers = () => dispatch => (
	fetchUsers().then(users => dispatch(receiveUsers(users)))
);

export const requestNotebooks = userId => dispatch => (
	fetchNotebooks(userId).then(notebooks => dispatch(receiveNotebooks(notebooks)))
);
