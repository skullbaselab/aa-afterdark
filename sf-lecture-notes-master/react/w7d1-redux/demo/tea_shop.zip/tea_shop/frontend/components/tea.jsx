import React from 'react';

export default ({ tea, idx }) => (
  <li key={idx}>{tea}</li>
);
