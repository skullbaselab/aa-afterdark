import React from 'react';
import PostsIndexItem from './index_item.jsx';

const PostsIndex = ({posts}) => {
  return (
    <ul className="posts-index">
      {posts.map(function (post) {
        return <PostsIndexItem key={post.id} post={post} />;
      })}
    </ul>
  );
};

export default PostsIndex;
