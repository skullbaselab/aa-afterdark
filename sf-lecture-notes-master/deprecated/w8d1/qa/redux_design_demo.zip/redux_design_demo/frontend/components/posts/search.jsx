import React from 'react';
import PostsSearchBox from './search_box';
import PostsIndex from './index';

const Search = ({posts, searchParams, updateSearchParam}) => {
  return (
    <div className="container">
      <PostsSearchBox
        searchParams={searchParams}
        updateSearchParam={updateSearchParam} />
      <PostsIndex posts={posts} />
    </div>
  );
};

export default Search;
