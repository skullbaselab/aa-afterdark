class Bike < ActiveRecord::Base
  has_many :bike_rentals,
    primary_key: :id,
    foreign_key: :bike_id,
    class_name: "Rental"

  has_many :renters,
    through: :bike_rentals,
    source: :renters
end
