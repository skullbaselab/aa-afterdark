class Plant < ActiveRecord::Base
  validates :name, presence: true
  validates :plant_type, inclusion: ["Tree", "Shrub", "Vine"]
end
