import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../reducers/root_reducer';
import thunkMiddleware from '../middleware/thunk_middleware';

const state = {posts:
                {1: {
                      title: "post 1",
                      body: "hello!",
                      id: 1
                    }
                }
              };

const configureStore = (preloadedState = state) => (
  createStore(rootReducer, preloadedState, applyMiddleware(thunkMiddleware))
);

export default configureStore;
