import React from 'react';

import GiphysIndex from './giphys_index';
