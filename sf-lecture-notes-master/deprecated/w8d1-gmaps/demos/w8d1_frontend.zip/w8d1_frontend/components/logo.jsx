import React from 'react';

export default () => (
  <h1>PoW</h1>
)