import React from 'react';
import { Provider } from 'react-redux';
import PostsSearchContainer from './posts/search_container.jsx';

const Root = ({store}) => (
  <Provider store={store}>
    <PostsSearchContainer />
  </Provider>
);

export default Root;
