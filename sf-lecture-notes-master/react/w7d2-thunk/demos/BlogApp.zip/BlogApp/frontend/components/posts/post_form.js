import React from 'react';

class PostForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: '',
      body: '',
      id: 2
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  update(property) {
    return e => this.setState({[property]: e.target.value});
  }

  handleSubmit(e) {
    e.preventDefault();
    this.props.createPost(this.state);
    this.setState({title: '', body: '', id: this.state.id + 1});
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <label>Title:
          <input
            value={this.state.title}
            onChange={this.update('title')}
            />
        </label>
        <label>Body:
          <textarea
            value={this.state.body}
            onChange={this.update('body')}>
          </textarea>
        </label>
        <button>Create Post!</button>
      </form>
    );
  }
};

export default PostForm;
