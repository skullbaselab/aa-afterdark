import React from 'react';
import Logo from './logo';
import SearchBar from './search_bar';
// import WhiskyIndex from './whiskyIndex';

export default () => (
  <div>
    <Logo />
    <SearchBar />
  </div>
)