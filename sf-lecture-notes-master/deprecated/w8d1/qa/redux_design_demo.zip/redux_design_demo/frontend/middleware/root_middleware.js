import { applyMiddleware } from 'redux';

import PostMiddleware from '../middleware/post_middleware';

const RootMiddleware = applyMiddleware(
  PostMiddleware
);

export default RootMiddleware;
