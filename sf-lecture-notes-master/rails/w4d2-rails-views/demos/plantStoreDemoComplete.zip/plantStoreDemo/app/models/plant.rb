class Plant < ActiveRecord::Base
  validates :name, presence: true
  validates :plant_type, inclusion: ["Tree", "Shrub", "Vine"]
  before_validation :test_byebug

  def test_byebug
    puts "Hello!"
  end
end
