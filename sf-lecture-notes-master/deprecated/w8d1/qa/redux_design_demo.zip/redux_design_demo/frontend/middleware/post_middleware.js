import { fetchPosts } from '../util/posts_api_util';
import { SearchParamConstants } from '../actions/search_param_actions';
import { PostConstants,
         requestPosts,
         receivePosts
       } from '../actions/post_actions';

export default ({getState, dispatch}) => next => action => {
  const result = next(action);
  switch(action.type){
    case PostConstants.REQUEST_POSTS:
      const searchParams = getState().searchParams;
      fetchPosts(searchParams, posts => dispatch(receivePosts(posts)));
      break;
    case SearchParamConstants.UPDATE_SEARCH_PARAM:
      dispatch(requestPosts());
      break;
    default:
      break;
  }
  return result;
};
