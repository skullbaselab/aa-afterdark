class AddIndicesToRentals < ActiveRecord::Migration
  def change
    add_index :rentals, :bike_id
    add_index :rentals, :renter_id
  end
end
