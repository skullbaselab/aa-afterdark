class Board < ApplicationRecord
end
