module.exports = {
  fetchPosts(params = {}, callback) {
    $.ajax({ url: "/api/posts", data: params, success: callback });
  },
};
