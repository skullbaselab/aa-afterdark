import React from 'react';

const BlankNotebook = () => (
		<section className="blank-notebook">
			<p>Click on the Users to See their Notebooks!</p>
		</section>
);

export default BlankNotebook;
