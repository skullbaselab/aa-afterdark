(function ($) {
  //immediately give it a white on black look
  //when hovered over, rotate 360 in 1 second
  //and change color to whatever color this thing says
  $.Colorify = function(el){
    this.$el = $(el);
    this.color = this.$el.text();
    this.$el.css("display", "block")
        .css("border", "1px solid gray")
        .css("width", "50px")
        .css("transition", "background-color 1s, transform 1s")
        .css("height", "50px");

    this.$el.on("mouseenter", this.magic.bind(this));
    this.$el.on("mouseleave", this.reset.bind(this));
  };

  $.Colorify.prototype.magic = function () {
    this.$el.css("transform", "rotate(300deg)")
            .css("background-color", this.color);
  };
  $.Colorify.prototype.reset = function () {
    this.$el.css("transform", "rotate(0deg)")
            .css("background-color", "white");
  };

  $.fn.colorify = function(){
    //this is the jquery selected thing
    this.each(function(){
      // this is the individual elements
      new $.Colorify(this);
    });
    return this;
  };
})(jQuery);
