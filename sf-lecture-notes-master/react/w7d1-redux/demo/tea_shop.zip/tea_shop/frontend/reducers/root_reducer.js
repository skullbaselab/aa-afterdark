import { combineReducers } from 'redux';
import teasReducer from './teas_reducer';
import cookiesReducer from './cookies_reducer';

export default combineReducers({
  teas: teasReducer,
  cookies: cookiesReducer
});
