export const SearchParamConstants = {
  UPDATE_SEARCH_PARAM: "UPDATE_SEARCH_PARAM"
};

export const updateSearchParam = (searchParam, value) => ({
  type: SearchParamConstants.UPDATE_SEARCH_PARAM,
  searchParam,
  value
});
