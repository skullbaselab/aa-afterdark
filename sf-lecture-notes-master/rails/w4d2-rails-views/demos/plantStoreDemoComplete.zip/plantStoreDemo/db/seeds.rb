# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

Plant.create!(name: "Aspen", plant_type: "Tree",
description: "Dancers in the garden, aspens are popular choices
for fast-growing windbreaks, screens, and mass plantings.
Their oval leaves flutter in the slightest breeze. These extremely
cold-hardy trees can gain almost 5 feet in height per year.
Avoid problems with their invasive roots and suckering by selecting
species and varieties that won't run rampant. ")

Plant.create!(name: "Bald Cypress", plant_type: "Tree",
description: "Bald cypress is an easy-to-grow North American native
conifer that features feathery, soft, green needles and attractive
peeling bark. Unlike many needled conifers, the needles turn a
delightful shade of russet-red in autumn, then fall off the tree in
winter revealing its delightful architectural shape. In spring, new
needles emerge.")

Plant.create!(name: "Beech Tree", plant_type: "Tree",
description: "A versatile, handsome tree, the beech takes center stage
in the garden come fall when leaves change to red, gold, orange, or
brown. Beech trees stand proudly upright or bend and weep; jagged
leaves vary from deep green to variegated rose, white, green, or
bronzy-purple. For the best leaf color, plant beeches in full sun.")

Plant.create!(name: "California Bay Laurel", plant_type: "Tree",
description: "Adaptable and easy to grow, California bay laurel is
native to the West Coast. It grows best in full sun to part shade,
and when planted in full sun and watered regularly, it can grow as
much as 4 feet each year. In partial shade with less-frequent watering,
it is a slow-growing yet lovely plant.")

Plant.create!(name: "Cedar Tree", plant_type: "Tree",
description: "Graceful sweeping branches and a natural pyramidal shape
are the hallmarks of this exceptionally fragrant evergreen. If given
plenty of space, cedars will grow to traffic-stopping perfection, to be
especially appreciated in the winter landscape. Needle color ranges from
yellow-tipped green to the silvery tones of the blue Atlas cedar. ")


Plant.create!(name: "Coast Rosemary", plant_type: "Shrub",
description: "A terrific coastal plant, coast rosemary stands up to
wind, salt spray, and drought conditions. This spreading, evergreen
shrub has a dense, rounded form if left unpruned. It takes shearing
well and can be sculpted to give it a more formal look. Its dark
gray-green leaves look similar to rosemary foliage, hence its common
name.")

Plant.create!(name: "Firecracker Flower", plant_type: "Shrub",
description: "Count on this neat and tidy evergreen shrub to explode
with color in late winter and early spring, when much of the landscape
is taking a break from flowering and green is the dominant hue. The
candy-corn-color blossoms of firecracker flower are a favorite nectar
source for hummingbirds.")

Plant.create!(name: "Gardenia", plant_type: "Shrub",
description: "It's easy to fall in love with gardenia, the queen of
fragrant flowers. This beautiful evergreen shrub produces a plethora
of heavily scented white rose-shape flowers throughout the warm months.
Even when it's not blooming, gardenia's glossy green foliage is
attractive. ")

Plant.create!(name: "Grape Holly", plant_type: "Shrub",
description: "Grape holly is a flashy star for the shade, with its red
new foliage and wands of sweetly scented yellow flowers in spring.
Blue-black berries follow. The spiny leaves resemble holly foliage,
but the color is a duller green that deepens to dusky tones in winter.
Shield grape holly from wind and sunburn in winter, and mulch it to
protect roots in winter.")

Plant.create!(name: "Hibiscus Bush", plant_type: "Shrub",
description: "Huge, showy blooms are the hallmark of the hibiscus
family, whether the flying saucers on hardy perennial hibiscus, the
Hawaiian charmers of the tropical hibiscus, or the frilly-flowered Rose
of Sharon that grows into a large shrub or small tree. ")

Plant.create!(name: "Hydrangea", plant_type: "Shrub",
description: "Hydrangeas, which come in types that can flourish in sun
or shade, offer huge bouquets of clustered flowers, in various
arrangements from mophead to lacecap from summer through fall.
Varieties of hydrangea differ in size of plant and flower shape, flower
color, and blooming time.")

Plant.create!(name: "Blackberry", plant_type: "Vine",
description: "Blackberries produce succulent fruit in summer on woody
canes. Beware that the vigorous woody canes can become invasive if not
pruned regularly. There are two distinct forms of blackberries --
trailing and erect. They may be thorny or thornless. Erect blackberries
are hardy, stiff-caned plants.")

Plant.create!(name: "Boston Ivy", plant_type: "Vine",
description: "Boston ivy, unlike most vines, waits until fall to put on
a show when its foliage turns a bold, rich red that rivals just about
any maple tree. It's a fast-growing vine that uses small adhesive disks
to attach to the side of a wall, fence, or other structure. Note: If
you pull the vine down, the adhesive disks remain attached to the
structure.")

Plant.create!(name: "Honeysuckle Vine", plant_type: "Vine",
description: "Hummingbirds adore honeysuckle vine, and after growing
one you will, too. These easy-care climbers offer attractive clusters
of blooms in a wide range of shades. The tube-shape flowers look great
mixed in with a variety of shrubs, perennials, and annuals.")

Plant.create!(name: "Jasmine", plant_type: "Vine",
description: "Few vines rival jasmine for beauty and fragrance.
This easy-to-grow climber produces beautiful clusters of starry
flowers you can smell from feet away. Most jasmines bloom in late
winter or early spring, but some such as Arabian jasmine will flower
throughout the year.")
