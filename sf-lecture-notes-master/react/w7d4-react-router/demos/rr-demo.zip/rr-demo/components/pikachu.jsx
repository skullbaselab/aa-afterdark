import React from 'react'

export default () => (
  <div>
    <img src="https://media.giphy.com/media/XrWcMWh8WDm00/giphy.gif" />
  </div>
)