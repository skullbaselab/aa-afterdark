# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

bike0 = Bike.create(color: "blue")
bike1 = Bike.create(color: "blue")
bike2 = Bike.create(color: "blue")
bike3 = Bike.create(color: "blue")
bike4 = Bike.create(color: "blue")
bike5 = Bike.create(color: "blue")
bike6 = Bike.create(color: "blue")
bike7 = Bike.create(color: "blue")
bike8 = Bike.create(color: "blue")
bike9 = Bike.create(color: "blue")
bike10 = Bike.create(color: "blue")
bike11 = Bike.create(color: "blue")
bike12 = Bike.create(color: "blue")

user1 = User.create(name: "jenn")
user2 = User.create(name: "Luke")
user3 = User.create(name: "Robert")
