50.times do
	User.create!(username: Faker::Internet.user_name,
							 email: Faker::Internet.email,
							 image_url: Faker::Avatar.image)
end

1_000.times do
	Notebook.create!(author_id: rand(50),
									 title: Faker::Book.title,
									 description: Faker::Hipster.sentence(9))
end
