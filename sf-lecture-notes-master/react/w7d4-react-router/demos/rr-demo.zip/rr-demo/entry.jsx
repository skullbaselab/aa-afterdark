import React from 'react'
import ReactDOM from 'react-dom'
import { HashRouter } from 'react-router-dom'
import App from './components/'

const Root = () => (
  <HashRouter>
    <App />
  </HashRouter>
)

document.addEventListener('DOMContentLoaded', () => {
  const main = document.getElementById('main')
  ReactDOM.render(
    <Root />,
    main
  )
})
