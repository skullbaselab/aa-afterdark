# == Schema Information
#
# Table name: gyms
#
#  id   :integer          not null, primary key
#  name :string           not null
#

class Gym < ActiveRecord::Base
  validates :name, presence: true

  has_many :coaches,
    foreign_key: :gym_id,
    primary_key: :id,
    class_name: 'Coach'

  has_many :fighters,
    through: :coaches,
    source: :fighters
end
