**Associations!**

Welcome to the associations exercise.

Check out the [`db/schema.rb`][schema] to see what your database will look like.

Check out [`db/seeds.rb`][seedfile] to see what test data your database contains.

The database has already been created and is standing by for your usage.

[schema]: ./db/schema.rb
[seedfile]: ./db/seeds.rb
