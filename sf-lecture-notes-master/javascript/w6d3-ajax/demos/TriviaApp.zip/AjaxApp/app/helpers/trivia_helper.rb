module TriviaHelper
end
