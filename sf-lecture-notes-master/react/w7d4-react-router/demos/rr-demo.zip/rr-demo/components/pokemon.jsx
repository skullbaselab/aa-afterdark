import React from 'react'

export default () => (
  <div>
    <img src="https://media.giphy.com/media/vsyKKf1t22nmw/giphy.gif" />
  </div>
)