# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

Post.destroy_all
Post.create!((1..25).map do
  {
    title: Faker::Hipster.words(rand(1..3)).join(' ').titleize,
    body: Faker::Hipster.sentence
  }
end)
