import { connect } from 'react-redux';
import Search from './search';
import { updateSearchParam } from '../../actions/search_param_actions';

const mapStateToProps = ({posts, searchParams}) => ({
  posts,
  searchParams
});

const mapDispatchToProps = dispatch => ({
  updateSearchParam: (searchParam, value) => {
    return dispatch(updateSearchParam(searchParam, value));
  }
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Search);
