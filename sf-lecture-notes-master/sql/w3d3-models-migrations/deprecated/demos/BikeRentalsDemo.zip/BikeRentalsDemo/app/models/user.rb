class User < ActiveRecord::Base
  validates :name, presence: true

  has_many :rentals,
    primary_key: :id,
    foreign_key: :renter_id,
    class_name: "Rental"

  has_many :bike_rentals,
    through: :rentals,
    source: :bikes

end
