export const PostConstants = {
  REQUEST_POSTS: "REQUEST_POSTS",
  POSTS_RECEIVED: "POSTS_RECEIVED"
};

export const requestPosts = () => ({
  type: PostConstants.REQUEST_POSTS
});

export const receivePosts = posts => ({
  type: PostConstants.POSTS_RECEIVED,
  posts
});
