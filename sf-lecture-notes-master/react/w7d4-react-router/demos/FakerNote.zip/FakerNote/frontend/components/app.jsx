import React from 'react';
import { Provider } from 'react-redux';
import { Router, Route, hashHistory, IndexRoute } from 'react-router';
import Home from './home';
import Splash from './splash';

import UsersContainer from './users_container';
import NotebooksContainer from './notebooks_container';
import { requestNotebooks, removeNotebooks } from '../actions/actions';

const App = ({store}) => {

	const fetchNotebooks = nextState => (
		store.dispatch(requestNotebooks(nextState.params.userId))
	)

	const clearNotebooks = () => (
		store.dispatch(removeNotebooks())
	)

	return (
		<Provider store={store}>
			<Router history={hashHistory}>
				<Route path='/' component={Home}>
					<IndexRoute component={Splash}/>
					<Route path='users' component={UsersContainer}>
						<Route path=':userId/notebooks' component={NotebooksContainer}
									 onEnter={fetchNotebooks} onLeave={clearNotebooks}/>
					</Route>
				</Route>
			</Router>
		</Provider>
	);
};

export default App;
