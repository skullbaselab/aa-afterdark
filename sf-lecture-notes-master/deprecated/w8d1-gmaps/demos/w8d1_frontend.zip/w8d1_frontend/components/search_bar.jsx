import React from 'react';

export default () => (
  <form>
    <input type='text' placeholder='whiskys you like'/>
    <input type='submit' value='pour me one' />
  </form>
)