import { SearchParamConstants } from '../actions/search_param_actions';
import merge from 'lodash/merge';

const _defaultSearchParams = Object.freeze({});

const SearchParamsReducer = function(state = _defaultSearchParams, action) {
  if (action.type === SearchParamConstants.UPDATE_SEARCH_PARAM){
    const searchParam = {[action.searchParam]: action.value};
    const newState = merge({}, state, searchParam);

    if (newState[action.searchParam] === '') {
      delete newState[action.searchParam];
    }
    return newState;
  } else {
    return state;
  }
};

export default SearchParamsReducer;
