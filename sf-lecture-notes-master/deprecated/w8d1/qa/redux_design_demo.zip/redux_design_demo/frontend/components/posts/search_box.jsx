import React from 'react';

const PostsSearchBox = ({searchParams: {search}, updateSearchParam}) => {
  return (
    <nav className="posts-search-box">
      <label htmlFor="search-box">Search Posts</label>
      <br />
      <input
        id="search-box"
        value={search}
        onInput={e => updateSearchParam('search', e.target.value)} />
    </nav>
  );
};

export default PostsSearchBox;
