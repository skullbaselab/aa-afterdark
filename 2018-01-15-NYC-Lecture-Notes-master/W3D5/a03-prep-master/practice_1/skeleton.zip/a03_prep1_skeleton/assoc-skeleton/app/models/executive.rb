class Executive < ApplicationRecord
end
