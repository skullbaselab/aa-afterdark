import { connect } from 'react-redux';
import PostIndex from './post_index';
import { fetchPosts, createPost, deletePost } from '../../actions/post_actions';
// import { receivePost, removePost } from '../../actions/post_actions';

const mapStateToProps = state => ({
  posts: state.posts
});

const mapDispatchToProps = dispatch => ({
  fetchPosts: () => dispatch(fetchPosts()),
  createPost: post => dispatch(createPost(post)),
  deletePost: post => dispatch(deletePost(post))
});

export default connect(mapStateToProps, mapDispatchToProps)(PostIndex);
