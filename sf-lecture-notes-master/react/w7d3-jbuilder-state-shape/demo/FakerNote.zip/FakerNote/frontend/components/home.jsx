import React from 'react';

const Home = ({children}) => (
		<section>
			<h1>Fakernote</h1>
			{children}
		</section>
);

export default Home;
