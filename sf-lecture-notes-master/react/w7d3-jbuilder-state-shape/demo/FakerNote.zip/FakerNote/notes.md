1. refactor app into own component
2. refactor Home into own component
3. import router route and hashHistory
4. talk about history "https://github.com/reactjs/react-router/blob/master/docs/guides/Histories.md"
5. code router and home route
6. talk about hash and storing location state (statefulness)
7. add usersContainer route
8. talk about nested routes