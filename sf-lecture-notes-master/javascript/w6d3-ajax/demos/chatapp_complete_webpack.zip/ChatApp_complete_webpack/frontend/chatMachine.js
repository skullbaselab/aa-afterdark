  var ChatMachine = function($messageForm, $messageList){
    this.$messageForm = $messageForm;
    this.$messageList = $messageList;
    this.$messageForm.on('submit', this.submitMessage.bind(this));
  };
  ChatMachine.prototype.submitMessage = function (e) {
    e.preventDefault();
    var $authorInput = this.$messageForm.find('input[name="message[author]"]')
    var $messageInput = this.$messageForm.find('input[name="message[text]"]')
    var message = {
      author: $authorInput.val(),
      text: $messageInput.val()
    };
    $.ajax({
      url: "/messages",
      type: "POST",
      dataType: "json",
      data: { message: message },
      success: function(resp){
        this.$messageList.append("<li>" + resp.author + ": " + resp.text +  "</li>");
        $authorInput.val("");
        $messageInput.val("");
        this.loader && this.loader.remove();
      }.bind(this)
    });
    this.addLoader();
  };
  ChatMachine.prototype.addLoader = function () {
    this.loader = $("<div class='loader'>LOADING...</div>");
    this.$messageForm.append(this.loader);
  };

module.exports = ChatMachine;
