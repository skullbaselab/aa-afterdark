class CreateGymsAndCoaches < ActiveRecord::Migration
  def change
    create_table :coaches do |t|
      t.string "name", null: false
      t.integer "gym_id"
    end
    create_table :gyms do |t|
      t.string "name", null: false
    end

    add_column :fighters, :coach_id, :integer
  end
end
